function genesis() {
  return true
}

function validatePut() {
  return true
}

function validateCommit() {
  return true
}

function validateLink()
{
  return true
}

function uploadFile(path)
{
  debug(typeof path)
  file_hash = httpSend("http://localhost:5000/addfile/"+path);
  debug(file_hash)
  return file_hash;
}

function downloadFile(hash)
{
  ret = httpSend("http://localhost:5000/getfile/"+hash);
  return ret;
}
