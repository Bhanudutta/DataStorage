var Global = App.DNA.Hash;

function genesis() {
  return true
}

function getTBlock()
{
  time = (new Date()).getTime();
  tblock = (Math.floor(time/5000)).toString();
  return tblock;
}
function genesis() {
  return true
}
function Write(params)
{
  writer = params.writer;
  tag = params.tag;
  data = params.data;

  var hash = commit('StringData', data);
  var link = commit('HoloLinks',{
    Links: [
      {Base: writer,Link: hash, Tag: tag}
    ]
  });
  return link;
}

// function writeTimed(writer,data)
// {
//   var hash = commit('StringData', data);
//   var tag = getTBlock();
//   var link = commit('HoloLinks',{
//     Links: [
//       {Base: writer,Link: hash, Tag: tag}
//     ]
//   });
//   return link;
// }

function readTag(params)
{
  writer = params.writer;
  tag = params.tag;
  return (getLinks(writer,tag))
}

function unHash(hash)
{
  return get(hash)
}

function updateAt(params)
{
  links = readTag(params);
  index = params.index;
  newd = params.newd;
  dlink = links[index].Hash;
  update("StringData",newd,dlink);
  return true;
}

function updatelink(params)
{
  plink = params.link;
  newd = params.newd;
  tag = params.tag;
  writer = params.writer;
  newhash = update("StringData",newd,plink);

  commit('HoloLinks', {
      Links: [
        {
          Base: writer,
          Link: plink,
          Tag: tag,
          LinkAction: HC.LinkAction.Del
        }
      ]
    });
    var link = commit('HoloLinks',{
      Links: [
        {Base: writer,Link: newhash, Tag: tag}
      ]
    });

}

function validatePut() {
  return true
}

function validateCommit() {
  return true
}

function validateLink()
{
  return true
}
function validateMod() {
  return true
}
