function genesis() {
  return true
}

function validatePut() {
  return true
}

function validateCommit() {
  return true
}

function validateLink()
{
  return true
}

function getTime()
{
  time = (new Date()).getTime();
  return time;
}

function createMessage(text,sender)
{
  message = {data:text,time:""+getTime(),likes:0,sender:sender};
  return JSON.stringify(message);
}

function PostMessage(params)
{
  writer = params.writer;
  message = createMessage(params.text,call('userManager','getName',''))
  var hash = commit('StringData',message);
  var link = commit('HoloLinks',{
    Links: [
      {Base: writer,Link: hash, Tag: "msg"}
    ]
  });
  return link;
}

function commentOnPost(params)
{
  plink = params.plink;
  message = createMessage(params.text)
  link = call('readerWriter','Write',{writer:plink,tag:"comment",data:message});
}

function readMessages(convhash)
{
  msgs = [];
  mhashes = call('readerWriter','readTag',{writer:convhash,tag:"msg"});
  if(mhashes!=null)
  {
    d = JSON.parse(mhashes)
    var i=0;
    for(i=0;i<d.length;i++)
    {
      msg = call('readerWriter','unHash',d[i].Hash)
      msgs.push({msg:JSON.parse(msg),link:d[i].Hash});
    }
  }
  return JSON.stringify(msgs);
}


function dislikePost(plink)
{
  msg = call('readerWriter','unHash',plink);
  msg = JSON.parse(msg);
  msg.likes--;
  msg = JSON.stringify(msg);
  call('readerWriter','updatelink',{link:plink,newd:msg});
}
