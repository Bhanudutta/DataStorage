function genesis() {
  return true
}

function validatePut() {
  return true
}

function validateCommit() {
  return true
}

function validateLink()
{
  return true
}


var DNA = App.DNA.Hash;
var Agent = App.Agent.Hash;

function creategroupCounter(phash)
{
  call('readerWriter','Write',{writer:phash,tag:"gcounter",data:"0"});
}

function getgroupcounter()
{
  phash = call('userManager','getPublicHash',"");
  link = JSON.parse(call('readerWriter','readTag',{writer:phash,tag:"gcounter"}))[0].Hash
  gc = Number(call('readerWriter','unHash',link));
  gd = gc+1;
  call('readerWriter','updatelink',{link:link,newd:""+gd,tag:"gcounter",writer:phash});
  return gc;
}

function createGroup(Gname)
{
  gr = searchGroup(Gname);
  debug(gr);
  if(gr != null)
    return false;
  c = getgroupcounter();
  phash = call('userManager','getPublicHash',"");
  gid = phash+c;
  group = commit("StringData",gid);
  call('readerWriter','Write',{writer:DNA,tag:"Group"+Gname,data:group});
  call('readerWriter','Write',{writer:phash,tag:"glist",data:group});
  call('readerWriter','Write',{writer:group,tag:"gname",data:Gname});
  uname = call('userManager','getName','');
  call('readerWriter','Write',{writer:group,tag:"participant",data:uname});
  return true;
}

function searchGroup(name)
{
  var user = call('readerWriter','readTag',{writer:DNA,tag:'Group'+name})
  juser = JSON.parse(user);

  if(juser.length == 0)
  {
    return null;
  }
  else
  {
      userphash = call('readerWriter','unHash',juser[0].Hash);
      return userphash;
  }
}

function joingroup(Gname)
{
  group = searchGroup(Gname);
  mname = call('userManager','getName','');
  phash = call('userManager','getPublicHash','');
  call('readerWriter','Write',{writer:group,tag:"participant",data:mname});
  call('readerWriter','Write',{writer:phash,tag:"glist",data:group});
  return true;
}

function getAll(params)
{
  var users = call('readerWriter','readTag',{writer:DNA,tag:""});
  jusers = JSON.parse(users);
  var i=0;
  rusers=[];
  for(i=0;i<jusers.length;i++)
  {
    if(jusers[i].Tag.slice(0,5) == 'Group')
      rusers.push(jusers[i].Tag.slice(5));
  }
  return JSON.stringify(rusers);
}

function getglist(p)
{
  mph = call('userManager','getPublicHash',"");
  var users = call('readerWriter','readTag',{writer:mph,tag:"glist"})
  jusers = JSON.parse(users)
  return JSON.stringify(jusers);
}

function isinGlist(gname)
{
  list = JSON.parse(getglist(""));
  group = searchGroup(gname);
  var i=0;
  for(i=0;i<list.length;i++)
  {
    ch = call('readerWriter','unHash',list[i].Hash);
    if(ch == group)
      return true;
  }
  return false;
}


function send(params)
{
  msg = params.msg;
  gName = params.gName;
  group = searchGroup(gName);
  mhash = call('userManager','getPublicHash',"");
  if(group != null)
  {
    if(isinGlist(gName))
    {
      call('Messages','PostMessage',{writer:group,text:msg});//call('readerWriter','Write',{writer:group,tag:"msg",data:msg});
      return true;
    }
    else
    {
      joingroup(gName);
      call('Messages','PostMessage',{writer:group,text:msg});//call('readerWriter','Write',{writer:group,tag:"msg",data:msg});
      return true;
    }
  }
  return false;

}

function recieve(from)
{
  group = searchGroup(from);
  mhash = call('userManager','getPublicHash',"");
  msgs = [];
  mhashes = null;
  if(group != null)
  {
    msgs = call('Messages','readMessages',group);//call('readerWriter','readTag',{writer:group,tag:"msg"});
  }
  return msgs;
}

function likePost(params)
{
  plink = params.plink;
  cname = params.cname;
  group = searchGroup(cname);
  msg = call('readerWriter','unHash',plink);
  msg = JSON.parse(msg);
  msg.likes++;
  msg = JSON.stringify(msg);
  call('readerWriter','updatelink',{link:plink,newd:msg,tag:"msg",writer:group});
  return true;
}
