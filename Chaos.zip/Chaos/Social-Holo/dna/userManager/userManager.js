function genesis() {
  return true
}

function validatePut() {
  return true
}

function validateCommit() {
  return true
}

function validateLink()
{
  return true
}
var DNA = App.DNA.Hash;
var Agent = App.Agent.Hash;
function createUser(params)
{
  var name = params.name;
  var passmd5 = params.passmd5;

  user = call('Conversation','searchUser',name);
  if(user != "null")
    return false;
  var publicHash = commit("StringData",name)
  //x=httpSend("http://localhost:5000/addfile/abc");
  call('readerWriter','Write',{writer:publicHash,tag:'UserPass',data:passmd5});
  call('readerWriter','Write',{writer:publicHash,tag:'UserName',data:name});
  call('readerWriter','Write',{writer:DNA,tag:"User"+name,data:publicHash});
  call('Group','creategroupCounter',publicHash);
  debug("created"+publicHash)
  return true;
}

function login(params)
{
  var name = params.name;
  var passmd5 = params.passmd5;
  try{
      pHash = call('readerWriter','readTag',{writer:DNA,tag:"User"+name});
      pHash = JSON.parse(pHash)[0].Hash
      pHash = call('readerWriter','unHash',pHash);
      var real = call('readerWriter','readTag',{writer:pHash,tag:'UserPass'})
      real = JSON.parse(real)[0].Hash;
      real = call('readerWriter','unHash',real);
      if(passmd5 == real)
      {
        call('readerWriter','Write',{writer:Agent,tag:"CurrentUser",data:pHash});
        return true;
      }
      else
      {
        return false;
      }
    }catch(err)
    {
      debug("Catched"+err);
      return false;
    }
}

function logout(p)
{
  phl = call('readerWriter','readTag',{writer:Agent,tag:'CurrentUser'});
  jphl = JSON.parse(phl)
  hash = jphl[0].Hash;
  commit('HoloLinks', {
      Links: [
        {
          Base: Agent,
          Link: hash,
          Tag: "CurrentUser",
          LinkAction: HC.LinkAction.Del
        }
      ]
    });
  return true;
}

function getPublicHash(p)
{
  phl = call('readerWriter','readTag',{writer:Agent,tag:'CurrentUser'});
  try{
    jphl = JSON.parse(phl)
    hash = jphl[0].Hash;
    phash = call('readerWriter','unHash',hash);
    return phash;
    }
    catch(err)
    {
      debug("ye wala"+err)
      return false;
    }
}

function getName(p)
{
  phash = getPublicHash('')
  data = call('readerWriter','readTag',{writer:phash,tag:'UserName'})
  data = JSON.parse(data)
  data = data[0].Hash;
  return call('readerWriter','unHash',data);
}
