 function genesis() {
  return true
}

function validatePut() {
  return true
}

function validateCommit() {
  return true
}

function validateLink()
{
  return true
}
function validateMod() {
  return true
}
var DNA = App.DNA.Hash;
var P1_W_P2 = 0;
var P1_C_P2 = 1;

function searchUser(name)
{
  var user = call('readerWriter','readTag',{writer:DNA,tag:'User'+name})
  juser = JSON.parse(user);

  if(juser.length == 0)
  {
    return null;
  }
  else
  {
      userphash = call('readerWriter','unHash',juser[0].Hash);
      return userphash;
  }
}


function getAll(params)
{
  var users = call('readerWriter','readTag',{writer:DNA,tag:""});
  jusers = JSON.parse(users);
  var i=0;
  rusers=[];
  for(i=0;i<jusers.length;i++)
  {
    if(jusers[i].Tag.slice(0,4) == 'User')
      rusers.push(jusers[i].Tag.slice(4));
  }
  return JSON.stringify(rusers);
}

function mergeHash(h1,h2)
{
  s = [h1,h2];
  s.sort();
  r = s[0]+s[1];
  return r;
}
function createConvHash(params)
{
  mhash = params.mhash;
  uhash = params.uhash;
  convhash = commit("StringData",mergeHash(mhash,uhash));
  data = JSON.stringify({p1:mhash,p2:uhash,status:P1_W_P2});
  link = call('readerWriter','Write',{writer:convhash,tag:"convstatus",data:data});
  call('readerWriter','Write',{writer:mhash,tag:"convlist",data:convhash});
  call('readerWriter','Write',{writer:uhash,tag:"convlist",data:convhash});
  return convhash;
}

function getConvlist(p)
{
  mph = call('userManager','getPublicHash',"");
  var users = call('readerWriter','readTag',{writer:mph,tag:"convlist"})
  jusers = JSON.parse(users)
  return JSON.stringify(jusers);
}

function isinConvlist(user)
{
  list = JSON.parse(getConvlist(""));
  mph = call('userManager','getPublicHash',"");
  var i=0;
  for(i=0;i<list.length;i++)
  {
    ch = call('readerWriter','unHash',list[i].Hash);
    cs = JSON.parse(call('readerWriter','readTag',{writer:ch,tag:"convstatus"}))[0].Hash;
    cs = JSON.parse(call('readerWriter','unHash',cs));
    if(cs.p1==user || cs.p2==user)
    {
      if(user == mph && cs.p1!=cs.p2)
        return false;
      return ch;
    }
  }
  return false;
}

function send(params)
{
  msg = params.msg;
  convName = params.convName;
  user = searchUser(convName);
  mhash = call('userManager','getPublicHash',"");
  if(user != null)
  {
    is = isinConvlist(user)
    if(is != false)
    {
      //call('readerWriter','Write',{writer:is,tag:"msg",data:msg});
      call('Messages','PostMessage',{writer:is,text:msg});
      return true;
    }
    else
    {
      ch = createConvHash({mhash:mhash,uhash:user})
      //call('readerWriter','Write',{writer:ch,tag:"msg",data:msg});
      call('Messages','PostMessage',{writer:ch,text:msg});
      return true;
    }
  }
  return false;

}

function recieve(from)
{
  user = searchUser(from);
  mhash = call('userManager','getPublicHash',"");
  msgs = [];
  mhashes = null;
  if(user != null)
  {
    is = isinConvlist(user)
    if(is != false)
    {
      msgs = call('Messages','readMessages',is);//call('readerWriter','readTag',{writer:is,tag:"msg"});
    }
  }
  return msgs;
}



function likePost(params)
{
  plink = params.plink;
  cname = params.cname;
  user = searchUser(cname);
  convhash = isinConvlist(user);
  msg = call('readerWriter','unHash',plink);
  msg = JSON.parse(msg);
  msg.likes++;
  msg = JSON.stringify(msg);
  call('readerWriter','updatelink',{link:plink,newd:msg,tag:"msg",writer:convhash});
  return true;
}
