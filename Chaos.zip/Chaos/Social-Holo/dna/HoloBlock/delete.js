function genesis() {
  return true
}

function validatePut() {
  return true
}

function validateCommit() {
  return true
}

function validateLink()
{
  return true
}

var DNA = App.DNA.Hash;

var FORMAT_NUM = 0
var FORMAT_ALPHA = 1
var FORMAT_ASCII = 2

function createCounter(params)
{
  writer = params.writer;
  name = params.name;

  call('readerWriter','Write',{Writer:writer,tag:name,data:'{count:0,}'})
}
