function genesis() {
  return true
}

function validatePut() {
  return true
}

function validateCommit() {
  return true
}

function validateLink()
{
  return true
}

var DNA = App.DNA.Hash;

function getHBCount(convh)
{
  hbCount = call('readerWriter','readTag',{writer:convhash,tag:'hbCount'})[0].Hash;
  return hbCount;
}

function Next(chash)
{
  convhash = chash;
  hbc = getHBCount(convhash);
  var c;
  if(hbc==null)
  {
    call('readerWriter','Write',{writer:convhash,tag:'hbCount',data:'0'});
    c = 0;
    wrt = makeHash('StringData',c.toString())
    call('readerWriter','Write',{writer:convhash,tag:'HB'+c.toString(),data:wrt})
    call('readerWriter','Write',{writer:wrt,tag:'Mcount',data:'0'});
  }
  else
  {
    c = hbc.number();
    mc = call('readerWriter','readTag',{writer:wrt,tag:'Mcount'})[0].Hash;
    if(mc.number() > 10)
    {
      c++;
      call('readerWriter','Write',{writer:convhash,tag:'hbCount',data:c.toString()});
      wrt = makeHash('StringData',c.toString())
      call('readerWriter','Write',{writer:convhash,tag:'HB'+c.toString(),data:wrt})
      call('readerWriter','Write',{writer:wrt,tag:'Mcount',data:'0'});
    }
  }
  return c;
}


function Push(params)
{
  convhash = params.convhash;
  c = Next(convhash);
  msg = convhash.msghash;
  wrt = call('readerWriter','readTag',{writer:convhash,tag:'HB'+c.toString()})[0].Hash;
  //update counter
  call('readerWriter','Write',{writer:wrt,tag:'Message',data:msg});
}

function Read(params)
{
  convhash = params.convhash;
  c = params.index;
  wrt = call('readerWriter','readTag',{writer:convhash,tag:'HB'+c.toString()})[0].Hash;
  msgs = call('readerWriter','readTag',{writer:wrt,tag:'Message'});
}
