function genesis() {
  return true
}

function validatePut() {
  return true
}

function validateCommit() {
  return true
}

function validateLink()
{
  return true
}

function createCounter(params)
{
  msgHash = params.msgHash;
  cid = params.cid;
  data = JSON.stringify({counterid:cid,value:0})
  link = call('readerWriter','Write',{writer:msgHash,tag:"counter",data:data});
  return true;
}

function updateCounter(params)
{
  msgHash = params.msgHash;
  cid = params.cid;
  by = params.by;
  links = call('readerWriter','readTag',{writer:msgHash,tag:"counter"});
  jlinks = JSON.parse(links)
  var i=0;
  for(i=0;i<jlinks.length;i++)
  {
    uh = call('readerWriter','unHash',jlinks[i]);
    c = JSON.parse(uh).cid;
    if(c==cid)
    {
      data = c;
      data.value+=by;
      call('readerWriter','updatelink',{writer:msgHash,tag:"counter",newd:data,link:jlinks[i]});
    }
  }
}

function addData(params)
{
  msgHash = params.msgHash;
  cid = params.cid;
  data = params.data;
  link = call('readerWriter','Write',{writer:msgHash,tag:"data",data:data});
  return true;
}
