
function createblock(id,container)
{
  if(document.getElementById(id)==null)
    {
      element = "<ul id="+id+"></ul>";
      container.insertAdjacentHTML('beforeend',element);
    }
  else
    {
      document.getElementById(id).innerHTML="";
    }
}
function printMessages(message,listid)
{
  msg = message;
  list = document.getElementById(listid);
  element = '<li>'+msg+'</li>'
  console.log('chala')
  list.insertAdjacentHTML('beforeend', element);
}
