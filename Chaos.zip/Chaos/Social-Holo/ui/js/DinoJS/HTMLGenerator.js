class HTMLGenerator
{
  constructor(name)
  {
    this.name = name;
    this.html = "";
  }
  
}
