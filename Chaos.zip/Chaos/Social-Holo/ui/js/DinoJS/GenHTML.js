idi = 0;

function GetHTML(name,object)
{
  let HTML = "";
  let DOMArray = [];
  if(Array.isArray(object))
      {
        let len = object.length;
        for(i=0;i<len;i++)
            {
              let GM=GetHTML(name,object[i]);
              HTML+=GM[0];
              DOMArray.push(GM[1])
            }
      }
  else{

  let datas = "";
  let details = "";
  let tag = "div"
  let id = ""+idi;
  for(let key in object)
  {
    if (object.hasOwnProperty(key))
    {
      if(key[0] == '_')
      {
        datas+=" "+key.slice(1)+"="+object[key]+" ";
        if(key.includes("id"))
        {
          id = object[key];
        }
      }
      else if (key[0] == '$')
      {
        let GH = GetHTML(name,object[key])
        details += ""+GH[0];
        DOMArray.push(GH[1])
      }
      else if(key[0] == '@')
      {
        tag = object[key];
      }
      else
        details += ""+object[key];
    }
  }
  if(id == idi)
  {
    datas+="id="+name+""+idi;
    DOMArray.push(name+""+id);
  }
  else DOMArray.push(id);
  HTML += "<"+tag+" "+datas+">"+details+"</"+tag+">";
  }
  idi+=1;
  return [HTML,DOMArray];
}


class HTML
{
  constructor(name)
  {
    this.name = name;
    this.Text = "";
    this.DOMArray = [];
    this.object = null;
  }
  SetObject(object)
  {
    this.object = object;
  }
  Get()
  {
    let GM = GetHTML(this.name,this.object)
    this.Text = GM[0];
    this.DOMArray = GM[1];
    return this.Text;
  }
  GetDOMArray()
  {
    return this.DOMArray;
  }
}
