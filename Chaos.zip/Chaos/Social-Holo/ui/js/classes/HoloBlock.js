class HoloBlock
{
  
}
