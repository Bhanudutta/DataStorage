class User
{
  register(name,passmd5,callback)
  {
    var data = {name:name,passmd5:passmd5};
    send(JSON.stringify(data),'userManager','createUser',(function (ret){console.log(ret);callback(ret)}));
  }
  login(name,passmd5,callback)
  {
    var data = {name:name,passmd5:passmd5};
    send(JSON.stringify(data),'userManager','login',(function (ret){console.log(ret);callback(ret)}));
  }
}
