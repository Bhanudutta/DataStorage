
app = angular.module('chaos', ['ngSanitize']);
app.controller('FeedCtrl', ['$scope', '$http','$interval', function ($scope, $http,$interval) {
$scope.posts = [];
$scope.readp = function () {

     var config = {
        headers : {
            'Content-Type': 'application/json;'
        }
    }
    corg = "";
    if(Gtype == 0)
    corg = "Conversation"
    else corg = "Group"
     $http.post('/fn/'+corg+'/recieve',Gselected,config)
     .then(function(response) {
              console.log(response.data)
        $scope.posts = response.data;
        });
}

$scope.like = function (link,uname) {

     var config = {
        headers : {
            'Content-Type': 'application/json;'
        }
    }
    data = {plink:link,cname:uname}
    corg = "";
    if(Gtype == 0)
    corg = "Conversation"
    else
    {
      corg = "Group"
      data.cname = Gselected;
    }
     $http.post('/fn/'+corg+'/likePost',JSON.stringify(data),config)
     .then(function(response) {
              console.log(response.data)
        });
}

$scope.readp();
$interval(function () {
    if(Gtype!=null)
      $scope.readp();
  }, 1000);

$scope.sendp = function () {
    msg = document.getElementById("message").value;
    message(Gselected,Gtype,msg);
  }
}]);


app.controller('ContactCtrl', ['$scope', '$http','$interval', function ($scope, $http,$interval) {
$scope.contacts = [];
$scope.bgColor = "white"
$scope.readc = function () {
     var config = {
        headers : {
            'Content-Type': 'application/json;'
        }
    }
     $http.post('/fn/Conversation/getAll','',config)
     .then(function(response) {
        $scope.contacts = response.data;
        });
}

$scope.readc();
$interval(function () {
    $scope.readc();
  }, 1000);

$scope.select = function (con) {
    Gselected = con;
    Gtype = 0;
    $scope.bgColor = "gray"
  }
}]);




app.controller('GroupCtrl', ['$scope', '$http','$interval', function ($scope, $http, $interval) {
$scope.groups = [];

$scope.readg = function () {
     var config = {
        headers : {
            'Content-Type': 'application/json;'
        }
    }

     $http.post('/fn/Group/getAll','',config)
     .then(function(response) {
        $scope.groups = response.data;
        });
}
$scope.readg();
$interval(function () {
    $scope.readg();
  }, 1000);

$scope.select = function (con) {
    Gselected = con;
    Gtype = 1;
  }
}]);
