
Gselected = null;
Gtype = null;

function message(username,type,message)
{
  if(type == 0)
  {
    send(JSON.stringify({msg:message,convName:username}),'Conversation','send',function(data)
    {
      console.log(data);
    });
  }
  else
  {
    send(JSON.stringify({msg:message,gName:username}),'Group','send',function(data)
    {
      console.log(data);
    });
  }
}

function logout()
{
  send('','userManager','logout',function(data)
  {
    console.log(data);
    window.location = "/Pages/register.html";
  });
}

// function recievemessage(divid)
// {
//   send("",'Conversation','recieve',function(data)
//   {
//     marray = JSON.parse(data);
//   });
// }
// function setSendButton(divid)
// {
//   document.getElementById(divid).addEventListener("click",
//       function(event)
//       {
//         msg = document.getElementById("message").value;
//         user = selected;
//         event.preventDefault();
//         message(user,msg);
//       }
//   );
// }

// document.getElementById("recieve").addEventListener("click",
//     function(event)
//     {
//       event.preventDefault();
//       recievemessage('posts');
//     }
// );
